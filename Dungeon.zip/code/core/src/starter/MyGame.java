package starter;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;

import controller.Game;
import tools.Constants;
import tools.Point;
import mygame.Hero;

import controller.Game;
import basiselements.hud.ScreenButton;
import basiselements.hud.ScreenImage;
import basiselements.hud.TextButtonListener;
import controller.ScreenController;

/**
 * The entry class to create your own implementation.
 *
 * <p>
 * This class is directly derived form {@link Game} and acts as the {@link
 * com.badlogic.gdx.Game}.
 */
public class MyGame extends Game {
    private Hero hero;
    private int zoomLevel = 10;
    private ScreenController screenController;

    @Override
    protected void setup() {
        hero = new Hero();
        entityController.add(hero);
        screenController = new ScreenController(batch);
        //System.out.println(camera.zoom);

        ScreenImage screenImage = new ScreenImage("hud/BackgroundButton.png",
                new Point(0, Constants.WINDOW_HEIGHT - 50));
        screenController.add(screenImage);

        controller.add(screenController);

        ScreenButton screenButton = new ScreenButton("2D / 3D \n Umschalten",
                new Point(2, Constants.WINDOW_HEIGHT - 40),
                new TextButtonListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        System.out.println("Button gedrückt!");

                        Boolean activ3D = getActiv3D();

                        if (activ3D) {
                            hero.setActiv3D(false);
                            setActiv3D(false);
                            zoomLevel = 10;
                            camera.zoom = 0.05f * zoomLevel;
                        } else {
                            hero.setActiv3D(true);
                            setActiv3D(true);
                            zoomLevel = 7;
                            camera.zoom = 0.05f * zoomLevel;
                        }

                    }
                });

        screenController.add(screenButton);
        controller.add(screenController);

        // set the default generator
        // levelAPI.setGenerator(new RandomWalkGenerator());
        // load the first level
        levelAPI.loadLevel();
    }

    @Override
    protected void frame() {
        processPressedKeys();
    }

    private void processPressedKeys() {
        checkZoomingKeys();
        checkMovingKeys();
    }

    private void checkZoomingKeys() {
        if (Gdx.input.isKeyPressed(Input.Keys.I)) {
            zoomLevel++;
            camera.zoom = 0.05f * zoomLevel;
            //System.out.println(camera.zoom);
        }
        if (Gdx.input.isKeyPressed(Input.Keys.O)) {
            zoomLevel--;
            if (zoomLevel <= 0) {
                zoomLevel = 1;
            }
            camera.zoom = 0.05f * zoomLevel;
            //System.out.println(camera.zoom);
        }
    }

    private void checkMovingKeys() {
        if (Gdx.input.isKeyPressed(Input.Keys.U)) {
            Vector3 position = camera.position;
            camera.setFocusPoint(new Point(position.x, position.y + 1));
        }
        if (Gdx.input.isKeyPressed(Input.Keys.J)) {
            Vector3 position = camera.position;
            camera.setFocusPoint(new Point(position.x, position.y - 1));
        }
        if (Gdx.input.isKeyPressed(Input.Keys.H)) {
            Vector3 position = camera.position;
            camera.setFocusPoint(new Point(position.x - 1, position.y));
        }
        if (Gdx.input.isKeyPressed(Input.Keys.K)) {
            Vector3 position = camera.position;
            camera.setFocusPoint(new Point(position.x + 1, position.y));
        }
    }

    @Override
    public void onLevelLoad() {
        camera.follow(hero);
        hero.setLevel(levelAPI.getCurrentLevel());

        // camera.setFocusPoint(levelAPI.getCurrentLevel().getStartTile().getCoordinate().toPoint());
    }

    /**
     * The program entry point to start the dungeon.
     *
     * @param args command line arguments, but not needed.
     */
    public static void main(String[] args) {
        // start the game
        DesktopLauncher.run(new MyGame());
    }
}
