package level.elements;

import level.elements.astar.TileHeuristic;
import level.tools.Coordinate;
import level.tools.DesignLabel;
import level.tools.LevelElement;
import level.tools.TileTextureFactory;

/**
 * A level is a 2D-Array of Tiles.
 *
 * @author Andre Matutat
 */
public class TileLevel implements ILevel {
    protected final TileHeuristic tileHeuristic = new TileHeuristic();
    protected Tile startTile;
    protected Tile endTile;
    protected int nodeCount = 0;
    protected Tile[][] layout;

    private static final Coordinate CONNECTION_OFFSETS[] = {
        new Coordinate(0, 1), new Coordinate(0, -1), new Coordinate(1, 0), new Coordinate(-1, 0),
    };
    /**
     * Create a new level
     *
     * @param layout The layout of the level.
     */
    public TileLevel(Tile[][] layout) {
        this.layout = layout;
        makeConnections();
        setRandomEnd();
        setRandomStart();
    }

    /**
     * Create a new Level
     *
     * @param layout The layout of the Level
     * @param designLabel The design the level should have
     */
    public TileLevel(LevelElement[][] layout, DesignLabel designLabel) {
        this(convertLevelElementToTile(layout, designLabel));
    }

    /**
     * Converts the given LevelElement[][] in a corresponding Tile[][]
     *
     * @param layout The LevelElement[][]
     * @param designLabel The selected Design for the Tiles
     * @return The converted Tile[][]
     */
    protected static Tile[][] convertLevelElementToTile(
            LevelElement[][] layout, DesignLabel designLabel) {
        Tile[][] tileLayout = new Tile[layout.length][layout[0].length];
        for (int y = 0; y < layout.length; y++) {
            for (int x = 0; x < layout[0].length; x++) {
                Coordinate coordinate = new Coordinate(x, y);
                String texturePath =
                        TileTextureFactory.findTexturePath(
                                new TileTextureFactory.LevelPart(
                                        layout[y][x], designLabel, layout, coordinate));
                tileLayout[y][x] = new Tile(texturePath, coordinate, layout[y][x], designLabel);
            }
        }
        return tileLayout;
    }

    @Override
    public int getNodeCount() {
        return nodeCount;
    }

    @Override
    public TileHeuristic getTileHeuristic() {
        return tileHeuristic;
    }

    /** Connect each tile with it neighbour tiles. */
    protected void makeConnections() {
        for (int x = 0; x < layout[0].length; x++) {
            for (Tile[] tiles : layout) {
                if (tiles[x].isAccessible()) {
                    tiles[x].setIndex(nodeCount++);
                    addConnectionsToNeighbours(tiles[x]);
                }
            }
        }
    }

    /**
     * Check each tile around the tile, if it is accessible add it to the connectionList.
     *
     * @param checkTile Tile to check for.
     */
    protected void addConnectionsToNeighbours(Tile checkTile) {
        for (Coordinate v : CONNECTION_OFFSETS) {
            Coordinate c =
                    new Coordinate(
                            checkTile.getCoordinate().x + v.x, checkTile.getCoordinate().y + v.y);
            Tile t = getTileAt(c);
            if (t != null && t.isAccessible()) {
                checkTile.addConnection(t);
            }
        }
    }

    @Override
    public Tile[][] getLayout() {
        return layout;
    }

    @Override
    public String[][] getLayoutFor3D() {
        System.out.println(printLevel());
        Tile[][] layoutOrginal = getLayout();
        String[][] layout3D = new String[layoutOrginal.length + 1][layoutOrginal[0].length + 1];
        for (int y = 0; y < layoutOrginal.length; y++) {
            for (int x = 0; x < layoutOrginal[0].length; x++) {

                if (layoutOrginal[y][x].getLevelElement() == LevelElement.FLOOR) {

                    // FloorNormal
                    layout3D[y + 1][x] = "FloorNormal3D";

                    // Links vom Floor Ende oder frei
                    if (x - 1 < 0 || (x - 1 >= 0 && layoutOrginal[y][x - 1].getLevelElement() == LevelElement.SKIP)) {
                        layout3D[y + 1][x] = "FloorRight3D";
                    }

                    // Rechts vom Floor frei
                    if (x + 1 < layoutOrginal[0].length
                            && layoutOrginal[y][x + 1].getLevelElement() == LevelElement.SKIP) {
                        layout3D[y + 1][x + 1] = "FloorLeft3D";

                        // falls Bereich oben zuende
                        if (y == layoutOrginal.length - 1) {
                            //überflüssig
                            layout3D[y + 1][x + 1] = "FloorLeftWallEnd3D";
                        } else {
                            if (layoutOrginal[y + 1][x + 1].getLevelElement() == LevelElement.FLOOR
                                    || layoutOrginal[y + 1][x + 1].getLevelElement() == LevelElement.EXIT) {
                                layout3D[y + 1][x + 1] = "FloorLeftWallCorner3D";
                            } else if (layoutOrginal[y + 1][x + 1].getLevelElement() == LevelElement.SKIP) {
                                layout3D[y + 1][x + 1] = "FloorLeftWall3D";
                                if (layoutOrginal[y + 1][x].getLevelElement() == LevelElement.SKIP) {
                                    layout3D[y + 1][x + 1] = "FloorLeftWallEnd3D";
                                }
                            }
                        }

                    }
                    // Rechts vom Floor Ende
                    else if (x + 1 == layoutOrginal[0].length) {
                        //falls oben Ende oder frei
                        if (y == layoutOrginal.length - 1 || (y < layoutOrginal.length - 1
                                && layoutOrginal[y + 1][x].getLevelElement() == LevelElement.SKIP)) {
                            layout3D[y + 1][x + 1] = "FloorLeftWallEnd3D";
                        } else {
                            layout3D[y + 1][x + 1] = "FloorLeftWall3D";
                        }

                    }

                    // Unterm Floor frei
                    if (y - 1 >= 0
                            && layoutOrginal[y - 1][x].getLevelElement() == LevelElement.SKIP) {

                        if (layout3D[y][x] == "Skip") {
                            layout3D[y][x] = "WallEndLeft3D";

                        }
                        if (x + 1 == layoutOrginal[0].length) {
                            layout3D[y][x + 1] = "WallCornerRight3D";
                        }

                        else {
                            if (layoutOrginal[y - 1][x + 1].getLevelElement() == LevelElement.FLOOR
                                    || layoutOrginal[y - 1][x + 1].getLevelElement() == LevelElement.EXIT) {
                                layout3D[y][x + 1] = "FloorRightWall3D";
                            } else {
                                if (layoutOrginal[y][x + 1].getLevelElement() == LevelElement.FLOOR
                                        || layoutOrginal[y][x + 1].getLevelElement() == LevelElement.EXIT) {
                                    layout3D[y][x + 1] = "WallNormal3D";
                                } else {
                                    layout3D[y][x + 1] = "WallCornerRight3D";
                                }
                            }
                        }

                    }

                    // Unterm Floor Ende
                    else if (y - 1 < 0) {
                        if (layout3D[y][x] == null) {
                            layout3D[y][x] = "WallEndLeft3D";
                        }
                        if (x + 1 == layoutOrginal[0].length) {
                            layout3D[y][x + 1] = "WallCornerRight3D";
                        } else {

                            if (layoutOrginal[y][x + 1].getLevelElement() == LevelElement.FLOOR
                                    || layoutOrginal[y][x + 1].getLevelElement() == LevelElement.EXIT) {
                                layout3D[y][x + 1] = "WallNormal3D";
                            } else {
                                layout3D[y][x + 1] = "WallCornerRight3D";
                            }
                        }

                    }

                } else if (layoutOrginal[y][x].getLevelElement() == LevelElement.SKIP) {
                    if (layout3D[y + 1][x] == null) {
                        layout3D[y + 1][x] = "Skip";
                    }
                } else if (layoutOrginal[y][x].getLevelElement() == LevelElement.EXIT) {
                    layout3D[y + 1][x] = "Exit";
                } else if (layoutOrginal[y][x].getLevelElement() == LevelElement.WALL) {
                    // do nothing
                } else {
                    layout3D[y + 1][x] = "Skip";
                }
            }

        }

        return layout3D;
    }

    @Override
    public Tile getStartTile() {
        return startTile;
    }

    @Override
    public void setStartTile(Tile start) {
        startTile = start;
        changeTileElementType(startTile, LevelElement.FLOOR);
    }

    @Override
    public Tile getEndTile() {
        return endTile;
    }

    @Override
    public void setEndTile(Tile end) {
        if (endTile != null) {
            changeTileElementType(endTile, LevelElement.FLOOR);
        }
        endTile = end;
        changeTileElementType(end, LevelElement.EXIT);
    }
}
