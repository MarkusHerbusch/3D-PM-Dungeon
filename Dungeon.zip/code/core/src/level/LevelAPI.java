package level;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import graphic.Painter;
import graphic.PainterConfig;
import java.util.HashMap;
import java.util.Map;
import level.elements.ILevel;
import level.elements.Tile;
import level.generator.IGenerator;
import level.tools.DesignLabel;
import level.tools.LevelElement;
import tools.Point;

/** Manages the level. */
public class LevelAPI {
    private final SpriteBatch batch;
    private final Painter painter;
    private final IOnLevelLoader onLevelLoader;
    private IGenerator gen;
    private ILevel currentLevel;
    private String[][] layout3D;

    /**
     * @param batch         Batch on which to draw.
     * @param painter       Who draws?
     * @param generator     Level generator
     * @param onLevelLoader Object that implements the onLevelLoad method.
     */
    public LevelAPI(
            SpriteBatch batch,
            Painter painter,
            IGenerator generator,
            IOnLevelLoader onLevelLoader) {
        this.gen = generator;
        this.batch = batch;
        this.painter = painter;
        this.onLevelLoader = onLevelLoader;
    }

    /** Load a new level. */
    public void loadLevel() {
        currentLevel = gen.getLevel();
        layout3D = currentLevel.getLayoutFor3D();
        onLevelLoader.onLevelLoad();
    }

    /**
     * Load a new level
     *
     * @param designLabel The design that the level should have
     */
    public void loadLevel(DesignLabel designLabel) {
        currentLevel = gen.getLevel(designLabel);
        layout3D = currentLevel.getLayoutFor3D();
        onLevelLoader.onLevelLoad();
    }

    /** Draw level */
    public void update(boolean activ3D) {
        drawLevel(activ3D);
    }

    /**
     * @return The currently loaded level.
     */
    public ILevel getCurrentLevel() {
        return currentLevel;
    }

    protected void drawLevel(boolean activ3D) {
        // 3D Veränderung ?
        if (activ3D) {
            drawLevel3D();
        }

        else {

            drawLevel2D();
        }
    }

    public void drawLevel2D() {
        Map<String, PainterConfig> mapping = new HashMap<>();
        Tile[][] layout = currentLevel.getLayout();

        for (int y = 0; y < layout.length; y++) {
            for (int x = 0; x < layout[0].length; x++) {
                Tile t = layout[y][x];
                if (t.getLevelElement() != LevelElement.SKIP) {
                    String texturePath = t.getTexturePath();
                    if (!mapping.containsKey(texturePath)) {
                        mapping.put(texturePath, new PainterConfig(texturePath));
                    }
                    painter.draw(
                            t.getCoordinate().toPoint(), texturePath, mapping.get(texturePath));
                }
            }
        }
    }

    public void drawLevel3D() {
        Map<String, PainterConfig> mapping = new HashMap<>();
        // PainterConfig painterConfig = new PainterConfig(0, 0, 1, 1);

        Tile[][] layout = currentLevel.getLayout();
        // String[][] layout3D = currentLevel.getLayoutFor3D();
        // System.out.println(currentLevel.printLevel());
        // System.out.println("Test");

        for (int y = 0; y < layout3D.length; y++) {
            for (int x = 0; x < layout3D[0].length; x++) {

                if (layout3D[y][x] != null && layout3D[y][x] != "Skip") {
                    // Default-Grafik
                    String texturePath = "textures/dungeon/default/floor/empty.png";

                    if (layout3D[y][x] == "FloorLeft3D") {
                        texturePath = "textures/dungeon/default/3D/floor_left.png";
                    }
                    if (layout3D[y][x] == "FloorLeftWall3D") {
                        texturePath = "textures/dungeon/default/3D/floor_left_wall.png";
                    }
                    if (layout3D[y][x] == "FloorLeftWallCorner3D") {
                        texturePath = "textures/dungeon/default/3D/floor_left_wall_corner.png";
                    }
                    if (layout3D[y][x] == "FloorLeftWallEnd3D") {
                        texturePath = "textures/dungeon/default/3D/floor_left_wall_end.png";
                    }
                    if (layout3D[y][x] == "FloorNormal3D") {
                        texturePath = "textures/dungeon/default/3D/floor_normal.png";
                    }
                    if (layout3D[y][x] == "FloorRight3D") {
                        texturePath = "textures/dungeon/default/3D/floor_right.png";
                    }
                    if (layout3D[y][x] == "FloorRightWall3D") {
                        texturePath = "textures/dungeon/default/3D/floor_right_wall.png";
                    }
                    if (layout3D[y][x] == "WallCornerRight3D") {
                        texturePath = "textures/dungeon/default/3D/wall_corner_right.png";
                    }
                    if (layout3D[y][x] == "WallEndLeft3D") {
                        texturePath = "textures/dungeon/default/3D/wall_end_left.png";
                    }
                    if (layout3D[y][x] == "WallNormal3D") {
                        texturePath = "textures/dungeon/default/3D/wall_normal.png";
                    }
                    if (layout3D[y][x] == "Exit") {
                        texturePath = "textures/dungeon/default/floor/floor_ladder.png";
                    }

                    if (!mapping.containsKey(texturePath)) {
                        mapping.put(texturePath, new PainterConfig(texturePath));
                    }
                    // unterste Reihe
                    if (y == 0) {
                        // ganz rechts
                        if (x == layout3D[0].length - 1) {
                            Tile t = layout[y][x - 1];
                            Point point3D = t.getCoordinate().toPoint();
                            point3D.x = ((point3D.x + (point3D.y * 0.5f)) - 0.5f) + 1;
                            point3D.y = (point3D.y / 2) - 0.5f;
                            painter.draw(
                                    point3D, texturePath, mapping.get(texturePath));
                        } else {
                            Tile t = layout[y][x];
                            Point point3D = t.getCoordinate().toPoint();
                            point3D.x = (point3D.x + (point3D.y * 0.5f)) - 0.5f;
                            point3D.y = (point3D.y / 2) - 0.5f;
                            painter.draw(
                                    point3D, texturePath, mapping.get(texturePath));
                        }

                        // nicht unten, aber ganz rechts
                    } else if (x == layout3D[0].length - 1) {
                        Tile t = layout[y - 1][x - 1];
                        Point point3D = t.getCoordinate().toPoint();
                        point3D.x = (point3D.x + (point3D.y * 0.5f)) + 1;
                        point3D.y = (point3D.y / 2);
                        painter.draw(
                                point3D, texturePath, mapping.get(texturePath));
                    }
                    // Normalfall
                    else {
                        Tile t = layout[y - 1][x];
                        Point point3D = t.getCoordinate().toPoint();
                        point3D.x = point3D.x + (point3D.y * 0.5f);
                        point3D.y = point3D.y / 2;
                        painter.draw(
                                point3D, texturePath, mapping.get(texturePath));
                        /*
                         * painter.draw(
                         * t.getCoordinate().toPoint(), texturePath, painterConfig);
                         */
                    }
                }
            }
        }

    }

    /**
     * @return The currently used Level-Generator
     */
    public IGenerator getGenerator() {
        return gen;
    }

    /**
     * Set the level generator
     *
     * @param generator new level generator
     */
    public void setGenerator(IGenerator generator) {
        gen = generator;
    }

    /**
     * Sets the current level to the given level and calls onLevelLoad().
     *
     * @param level The level to be set.
     */
    public void setLevel(ILevel level) {
        currentLevel = level;
        onLevelLoader.onLevelLoad();
    }
}
