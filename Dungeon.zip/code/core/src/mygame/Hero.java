package mygame;

//import basiselements.DungeonElement;
import basiselements.AnimatableElement;
import graphic.Animation;
import java.util.List;
import textures.TextureHandler;

import level.elements.ILevel;
import tools.Point;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;

/* Nur Held
public class Hero extends DungeonElement {
    private String texture = "character/knight/knight_m_idle_anim_f0.png";
    private Point currentPosition;
    private ILevel currentLevel;  */

public class Hero extends AnimatableElement {
    private Animation idle;
    private ILevel currentLevel;
    private Point currentPosition2D;
    private Point currentPosition3D;
    private boolean activ3D = false;

    // Animation
    public Hero() {
        List<String> texturePaths = TextureHandler.getInstance().getTexturePaths("knight_m_idle_anim_f");
        idle = new Animation(texturePaths, 5);
    }

    public void setLevel(ILevel level) {
        // System.out.println("SetLevel");
        currentLevel = level;
        currentPosition2D = level.getStartTile().getCoordinate().toPoint();

        // 3D Veränderung
        Point position3D = level.getStartTile().getCoordinate().toPoint();
        position3D.x = position3D.x + (position3D.y * 0.5f);
        position3D.y = position3D.y / 2;

        currentPosition3D = position3D;

    }

    @Override
    public void update() {
        // Temporären Point um den Held nur zu bewegen, wenn es keine Kollision gab
        Point newPosition = new Point(currentPosition2D);

        // Unser Held soll sich pro Schritt um 0.1 Felder bewegen.
        float movementSpeed = 0.1f;
        // Wenn die Taste W gedrückt ist, bewege dich nach oben
        if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            newPosition.y += movementSpeed;
        }
        // Wenn die Taste S gedrückt ist, bewege dich nach unten
        if (Gdx.input.isKeyPressed(Input.Keys.S)) {
            newPosition.y -= movementSpeed;
        }
        // Wenn die Taste D gedrückt ist, bewege dich nach rechts
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            newPosition.x += movementSpeed;
        }
        // Wenn die Taste A gedrückt ist, bewege dich nach links
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            newPosition.x -= movementSpeed;
        }
        // Wenn der übergebene Punkt betretbar ist, ist das nun die aktuelle Position
        Point newPositionCheckLeft = new Point(newPosition);
        // Verschiebung um 1 Pixel, 2 / 16 Feld 16 Pixel, Held unten 12 Pixel breit, 1
        // Pixel
        // Toleranz
        // newPositionCheckLeft.x += 0.125f;
        newPositionCheckLeft.x += 0.125f;
        Point newPositionCheckRight = new Point(newPosition);
        // Verschiebung um 15 Pixel 14 / 16 Feld 16 Pixel, Held unten 12 Pixel breit, 1
        // Pixel
        // Toleranz
        // newPositionCheckRight.x += 0.875f;
        newPositionCheckRight.x += 0.875f;
        // Überprüfung newPosition rausnehmen
        if (currentLevel.getTileAt(newPositionCheckLeft.toCoordinate()) != null
                && currentLevel.getTileAt(newPositionCheckRight.toCoordinate()) != null
                && currentLevel.getTileAt(newPositionCheckLeft.toCoordinate()).isAccessible()
                && currentLevel.getTileAt(newPositionCheckRight.toCoordinate()).isAccessible()) {
            // if (currentLevel.getTileAt(newPosition.toCoordinate()) != null &&
            // currentLevel.getTileAt(newPosition.toCoordinate()).isAccessible() ) {

            currentPosition2D = newPosition;
            // System.out.println(currentPosition2D.x + "+" + currentPosition2D.y);

            // 3D Veränderung
            // Point position3D = newPosition;
            // position3D.x = position3D.x + (position3D.y * 0.5f);
            // position3D.y = position3D.y / 2;

            // currentPosition3D = position3D;
            currentPosition3D.x = newPosition.x + (newPosition.y * 0.5f);
            currentPosition3D.y = newPosition.y / 2;

            // System.out.println(currentPosition2D.x + "+" + currentPosition2D.y);
            // System.out.println(currentPosition3D.x + "+" + currentPosition3D.y);

        }
    }

    @Override
    public Point getPosition() {

        if (activ3D) {

            return currentPosition3D;

        } else {

            return currentPosition2D;
        }
    }

    /*
     * Nur Held
     * 
     * @Override
     * public String getTexturePath() {
     * return texture;
     * }
     */

    // Annimaion
    @Override
    public Animation getActiveAnimation() {
        return idle;
    }

    /*
     * @Override
     * public boolean removable() {
     * return lebenspunkte == 0;
     * }
     */

    public void setActiv3D(boolean activ3D) {
        this.activ3D = activ3D;
    }

    public boolean getActiv3D() {
        return this.activ3D;
    }
}